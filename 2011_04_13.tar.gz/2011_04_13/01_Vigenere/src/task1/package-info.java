/**
 * Aufgabe 1: Ihre Implementierung der Vigenère-Chiffre.
 * <p>Folgende Eclipse-Run Configuration ist angelegt:
 * <ul>
 * <li>10 Vigenere makekey</li>
 * </ul>
 */

package task1;